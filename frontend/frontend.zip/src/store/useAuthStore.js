import { create } from "zustand";
import { axiosInstance } from "../lib/axios.js";
import toast from "react-hot-toast";

export const useAuthStore = create((set) => ({
    authUser: null,
    isSigningUp: false,
    isLogginIn: false,
    isUpdatingProfile: false,
    isCheckingAuth: true,

    checkAuth: async () => {
        try {
              /*const res = await fetch("http://localhost:5001/api/auth/check", {
              credentials: "include",
            });*/
            const res = await axiosInstance.get("/auth/check")
            set({authUser: res.data})
          } catch (err) {
            console.error("Auth check failed:", err);
            set({ authUser: null });
          } finally {
            set({ isCheckingAuth: false });
          }
    },

    signup: async (data) => {
      set({isSigningUp: true})
      try {
        const res = await axiosInstance.post("/auth/signup", data)
        set({authUser: res.data})
        toast.success("Account created successfully")
      } catch (error) {
        toast.error(error.response.data.message)
        //this is how we can grab the message that we are sending from signup
      } finally{
        set({isSigningUp: false})
      }
    },

    login: async (data) => {
      set({isLogginIn: true})
      try {
        const res = await axiosInstance.post("/auth/login", data)
        set({authUser: res.data})
        toast.success("Logged in successfully")
      } catch (error) {
        toast.error(error.response.data.message)
      } finally {
        set({isLogginIn: false})
      }
    },

    logout: async() => {
      try {
        axiosInstance.post("/api/logout")
        set({authUser: null})
        toast.success("Logged out successfully")
      } catch (error) {
        toast.error(error.response.data.message)
      }
    },

    updateProfile: async (data) => {
      set({isUpdatingProfile: true})
      try {
        const res = await axiosInstance.put("/auth/update-profile", data)
        set({authUser: res.data.user})
        toast.success("Profile updated successfully")
      } catch (error) {
        console.log("Error in updating profile", error)
        toast.error("Error in updating profile: ", error)
      } finally {
        set({isUpdatingProfile: false})
      }
    },
}))